# ChatClientServer_Python
<h1>
Chat Client &amp; Server (Python)
</h1>

<h2>
Tên đề tài : Xây dựng phần mềm chat Online(bằng Python) 
</h2>

<h2>
Thành viên:
</h2>

<h3>
<br>1.Nguyễn Đình Thái (Nhóm Trưởng) Email:thai.itplus@gmail.com - 0985243276 
<br>2.Trịnh Văn Bình
<h3>

<h2>
ĐỀ CƯƠNG XÂY DỰNG ĐỀ TÀI MÃ NGUỒN MỞ 4305 
</h2>

<p>
	<br>Phần 1: Giới thiệu GitHub, cách sử dụng, phát triển mã nguồn mở trên Github
	<br>Phần 2: Mô tả và mục tiêu: Giúp các chat & trao đổi thông tin giữa nhiều người dùng
	<br>Phần 3: Hướng xây dựng:
	<br>	ngôn ngữ nguồn mở triển khai: python
	<br>	Phạm Vi hoạt động: Online
	<br>	Triển khai trên Ubuntu, Linux
	<br>	Hỗ trợ nhiều client chat cùngc lúc
<h2>
<left><br>Nguyên Lý Hoạt Động
<h2>
<br><img src='/socket.jpg'></left>
</p>
